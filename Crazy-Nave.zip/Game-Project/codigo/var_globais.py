largura_tela = 768
altura_tela = 768

fonte = '../fonte/Pixeled.ttf'

cor_menu_fundo = (0,0,0)
cor_menu_branco = (255,255,255)
cor_menu_texto_selecionado = (154, 0, 0)

padroes_spawnados = 0
cooldown_spawn_padroes = 5000
cooldown_spawn_meteoro = 20000

#peso poweruo
modificador_do_peso = 0
peso_1 = 80 - modificador_do_peso * 3
peso_2 = 15 + modificador_do_peso * 2
peso_3 = 5 + modificador_do_peso

#chance de drop
chance_drop_aditivo = 0

#peso inimigo
modificador_peso_inimigo = 0
inimigo_peso_1 = 75 - modificador_peso_inimigo * 4
inimigo_peso_2 = 7.5 + modificador_peso_inimigo * 3
inimigo_peso_3 = 2.5 + modificador_peso_inimigo * 2
inimigo_peso_4 = 0 + modificador_peso_inimigo

#cooldown laser inimigos
alien_laser_cooldown = 1600
alien_azul_cooldown = 1800
alien_vermelho_cooldown = 2000